//
//  FieldMateV2App.swift
//  FieldMateV2
//
//  Created by Muhammad Ardiansyah Asrifah on 26/03/25.
//

import SwiftUI

@main
struct FieldMateV2App: App {
    var body: some Scene {
        WindowGroup {
            CalendarView()
        }
    }
}

//
//  TaskDetailView.swift
//  FieldMateV2
//
//  Created by Muhammad Ardiansyah Asrifah on 26/03/25.
//

//
//  TaskDetailView.swift
//  FieldMateV2
//
//  Created by Muhammad Ardiansyah Asrifah on 26/03/25.
//

import SwiftUI
import ActivityKit
import PDFKit

struct TaskDetailView: View {
    let task: CalendarTask
    @State private var selectedDate: Date
    @State private var isRescheduling = false
    @State private var selectedCategory: String = "AC"
    @State private var isCompleted: Bool = false

    let categories = ["AC", "Water Sprinkle", "Fire Alarm", "Lamp"]
    @State private var formResponses: [String: String] = [:]
    
    init(task: CalendarTask) {
        self.task = task
        _selectedDate = State(initialValue: task.startTime)
    }
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                
                Toggle(isOn: $isCompleted) {
                    Text(isCompleted ? "✅ Selesai" : "⏳ Belum Selesai")
                        .font(.headline)
                        .foregroundColor(isCompleted ? .green : .red)
                }
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(10)

                Text(task.title)
                    .font(.title)
                    .fontWeight(.bold)
                
                Text(task.description)
                    .font(.body)
                    .foregroundColor(.gray)
                
                Divider()
                
                Text("Waktu Tugas:")
                    .font(.headline)
                
                Button(action: {
                    withAnimation {
                        isRescheduling.toggle()
                    }
                }) {
                    Text("\(formattedTime(date: selectedDate))")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.blue)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(10)
                }
                
                if isRescheduling {
                    DatePicker("Pilih Waktu", selection: $selectedDate, displayedComponents: [.date, .hourAndMinute])
                        .datePickerStyle(GraphicalDatePickerStyle())
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(10)
                }
                
                Divider()
                
                Text("Pilih Kategori:")
                    .font(.headline)
                Picker("Kategori", selection: $selectedCategory) {
                    ForEach(categories, id: \.self) { category in
                        Text(category).tag(category)
                    }
                }
                .pickerStyle(MenuPickerStyle())
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(10)
                
                if let tableData = getTableData(for: selectedCategory) {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Form \(selectedCategory)")
                            .font(.headline)
                            .padding(.bottom, 4)
                        
                        ForEach(tableData, id: \.0) { row in
                            HStack {
                                Text(row.0)
                                    .frame(width: 150, alignment: .leading)
                                    .fontWeight(.semibold)
                                
                                Spacer()
                                
                                Picker("Status", selection: Binding(
                                    get: { formResponses[row.0] ?? row.1 },
                                    set: { formResponses[row.0] = $0 }
                                )) {
                                    Text("Baik").tag("Baik")
                                    Text("Kurang").tag("Kurang")
                                    Text("Rusak").tag("Rusak")
                                }
                                .pickerStyle(SegmentedPickerStyle())
                                .frame(width: 180)
                            }
                            .padding()
                            .background(Color(.systemGray6))
                            .cornerRadius(10)
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(10)
                    .shadow(radius: 3)
                }
                
                Button(action: {
                    exportToPDF(category: selectedCategory)
                }) {
                    Text("Export ke PDF")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding(.top, 10)
                
                Button(action: {
                    startLiveActivity(task: task)
                }) {
                    Text("Mulai Live Activity")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }

            }
            .padding()
        }
        .navigationTitle("Task Detail")
    }
    
    
    func formattedTime(date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: date)
    }
    
    func getTableData(for category: String) -> [(String, String)]? {
        switch category {
        case "AC":
            return [("Filter", "Baik"), ("Freon", "Baik"), ("Kompresor", "Baik")]
        case "Water Sprinkle":
            return [("Pompa", "Baik"), ("Nozzle", "Baik"), ("Pipa", "Baik")]
        case "Fire Alarm":
            return [("Sensor", "Baik"), ("Sirine", "Baik"), ("Panel", "Baik")]
        case "Lamp":
            return [("Lampu LED", "Baik"), ("Kabel", "Baik"), ("Sakelar", "Baik")]
        default:
            return nil
        }
    }
    
    func startLiveActivity(task: CalendarTask) {
        let attributes = FieldMateLiveActivityAttributes(taskID: task.id.uuidString)
        let state = FieldMateLiveActivityAttributes.ContentState(
            taskTitle: task.title,
            taskTime: formattedTime(date: task.startTime)
        )

        do {
            let activity = try Activity<FieldMateLiveActivityAttributes>.request(
                attributes: attributes,
                contentState: state,
                pushType: nil
            )
            print("✅ Live Activity dimulai: \(activity.id)")
        } catch {
            print("❌ Gagal memulai Live Activity: \(error)")
        }
    }
    

    
    func checkActiveLiveActivities() {
        let activities = Activity<FieldMateLiveActivityAttributes>.activities
        print("📌 Jumlah Live Activity aktif: \(activities.count)")
        for activity in activities {
            print("🔍 Active Live Activity ID: \(activity.id)")
        }
    }


    func updateLiveActivityManually(task: CalendarTask) {
        Task {
            for activity in Activity<FieldMateLiveActivityAttributes>.activities {
                await activity.update(using: FieldMateLiveActivityAttributes.ContentState(
                    taskTitle: "🔄 Updated: \(task.title)",
                    taskTime: formattedTime(date: task.startTime)
                ))
                print("🔄 Live Activity diperbarui dengan konten baru!")
            }
        }
    }



    func stopLiveActivity() {
        Task {
            let activities = Activity<FieldMateLiveActivityAttributes>.activities
            for activity in activities {
                await activity.end(dismissalPolicy: .immediate)
            }
        }
    }
    
    func exportToPDF(category: String) {
        let pdfDocument = PDFDocument()
        let pdfPage = PDFPageView(
            taskTitle: task.title,
            taskDescription: task.description,
            category: category,
            data: formResponses,
            isCompleted: isCompleted
        )
        
        let pdfPageView = UIHostingController(rootView: pdfPage).view!
        pdfPageView.frame = CGRect(x: 0, y: 0, width: 612, height: 792)
        
        let renderer = UIGraphicsPDFRenderer(bounds: pdfPageView.bounds)
        let data = renderer.pdfData { context in
            context.beginPage()
            pdfPageView.drawHierarchy(in: pdfPageView.bounds, afterScreenUpdates: true)
        }
        
        let tempURL = FileManager.default.temporaryDirectory.appendingPathComponent("Form_\(category).pdf")
        try? data.write(to: tempURL)
        
        let activityVC = UIActivityViewController(activityItems: [tempURL], applicationActivities: nil)
        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
            windowScene.windows.first?.rootViewController?.present(activityVC, animated: true)
        }
    }
}


struct PDFPageView: View {
    let taskTitle: String
    let taskDescription: String
    let category: String
    let data: [String: String]
    let isCompleted: Bool
    
    var body: some View {
        VStack(spacing: 12) {
            Text("Laporan Inspeksi")
                .font(.largeTitle)
                .bold()
            
            Text(taskTitle)
                .font(.title2)
                .fontWeight(.semibold)
                .multilineTextAlignment(.center)
            
            Text(taskDescription)
                .font(.body)
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 20)
            
            Text(isCompleted ? "✅ Status: Selesai" : "⏳ Status: Belum Selesai")
                .font(.headline)
                .foregroundColor(isCompleted ? .green : .red)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(10)
            
            ForEach(data.keys.sorted(), id: \.self) { key in
                HStack {
                    Text(key).bold().frame(width: 180, alignment: .leading)
                    Text(data[key] ?? "-").frame(maxWidth: .infinity, alignment: .trailing)
                }
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(8)
            }
            Spacer()
        }
        .padding()
    }
}





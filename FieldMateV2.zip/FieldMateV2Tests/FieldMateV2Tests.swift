//
//  FieldMateV2Tests.swift
//  FieldMateV2Tests
//
//  Created by Muhammad Ardiansyah Asrifah on 26/03/25.
//

import Testing
@testable import FieldMateV2

struct FieldMateV2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
